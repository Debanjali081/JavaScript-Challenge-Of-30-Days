// Task 2 : Write a program to check if a person is eligible to vote (age >=18) and  log the result to the console .

let age=prompt("Enter your age :");

(age>=18)?console.log(`Yes , the person is eligible to vote because age = ${age}`) : console.log(`No , the person is not eligible to vote because age = ${age}`) 