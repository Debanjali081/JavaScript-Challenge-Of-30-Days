// Task 6 : Write a program that uses the ternary operator to check if a number is even or odd and log the result to the console .

let num = prompt("Enter a number");

(num % 2 == 0) ? console.log("Even") : console.log("Odd");